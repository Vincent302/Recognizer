package Test;

import ImageTool.PicReader;

public class ImageTest {
	public static void main(String [] args){
		String filePath = "img/0.jpg";
		PicReader pr = new PicReader(filePath);
		double [] input = pr.doRun();

		System.out.println(input.length);
		for(int i=0;i<input.length;i++){
			System.out.print(input[i]);
		}
	}
}
