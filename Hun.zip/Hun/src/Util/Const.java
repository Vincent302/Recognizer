package Util;

public class Const {
	public static int PIC_WIDTH = 200;
	public static int PIC_HEIGHT = 200;
	public static int STEP = 40;
	public static int INPUT_WIDTH = PIC_WIDTH / STEP;
	public static int INPUT_HEIGHT = PIC_HEIGHT / STEP;
	public static int INPUT_NUMBER = INPUT_WIDTH * INPUT_HEIGHT;
	

	public static int PARAM_HIDDEN = INPUT_NUMBER;
	public static int PARAM_OUTPUT = 52;
	
	public static int TRAINING_TIME = 1000;
	
	
	
	public static double LEARNING_RATE = 0.25;
	public static double MONUMENT = 0.8;
}
