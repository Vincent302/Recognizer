package BP;

 
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;  

import Util.Const;
  
/** 
 * BP. 
 *  
 * @author Hun 
 *  
 */  
public class BP {  
	
    private final double[] input; 
    private final double[] hidden_layer;  
    private final double[] output;  
    private final double[] answer;  
    
    private final double[] hid_delta;  
    private final double[] opt_delta;  

    private final double learning_rate; 
    private final double momentum;  
  
    private final double[][] input_to_hidden_weight;  
    private final double[][] hidden_to_output_weight;  
    private final double[][] input_to_hidden_update_weight;  
    private final double[][] hidden_to_output_update_weight;  
  
    public double output_error = 0;  
    public double hidden_error = 0;  
  
    private final Random random;  
    
    private final String weight_file = "data/weight";
  
    /** 
     * Constructor. 
     * <p> 
     * <strong>Note:</strong> The capacity of each layer will be the parameter 
     * plus 1. The additional unit is used for smoothness. 
     * </p> 
     *  
     * @param input_size 
     * @param hidden_size 
     * @param output_size 
     * @param learning_rate 
     * @param momentum 
     * @param epoch 
     */  
    public BP(int input_size, int hidden_size, int output_size, double learning_rate, double momentum) {  
  
        input = new double[input_size + 1];  
        hidden_layer = new double[hidden_size + 1];  
        output = new double[output_size + 1];  
        answer = new double[output_size + 1];  
  
        hid_delta = new double[hidden_size + 1];  
        opt_delta = new double[output_size + 1];  
  
        input_to_hidden_weight = new double[input_size + 1][hidden_size + 1];  
        hidden_to_output_weight = new double[hidden_size + 1][output_size + 1];  
  
        random = new Random(19881211);  
        initWeight(input_to_hidden_weight);  
        initWeight(hidden_to_output_weight);  
  
        input_to_hidden_update_weight = new double[input_size + 1][hidden_size + 1];  
        hidden_to_output_update_weight = new double[hidden_size + 1][output_size + 1];  
  
        this.learning_rate = learning_rate;  
        this.momentum = momentum;  
    }  
  
    private void initWeight(double[][] weight) {  
        for(int i=0, len = weight.length; i!=len; i++){
        	for (int j = 0, len2 = weight[i].length; j != len2; j++){ 
                double real = random.nextDouble();  
                weight[i][j] = random.nextDouble() > 0.5 ? real : -real;  
            }
        }
    }
  
    /** 
     * Constructor with default eta = 0.25 and momentum = 0.3. 
     *  
     * @param input_size 
     * @param hidden_size 
     * @param output_size 
     * @param epoch 
     */  
    public BP(int input_size, int hidden_size, int output_size) {
        this(input_size, hidden_size, output_size, Const.LEARNING_RATE, Const.MONUMENT);  
    }  
  
    /** 
     * Entry method. The train data should be a one-dim vector. 
     *  
     * @param input 
     * @param answer 
     */  
    public void train(double[] input, double[] answer) {
        loadInput(input);  
        loadTarget(answer);  
        forward();  
        calculateDelta();  
        adjustWeight();  
    }  
  
    /** 
     * Test the BPNN. 
     *  
     * @param input_date 
     * @return 
     */  
    public double[] test(double[] input_date) {
        if (input_date.length != input.length - 1) {
            throw new IllegalArgumentException("Size Do Not Match.");  
        }  
        System.arraycopy(input_date, 0, input, 1, input_date.length);  
        forward();  
        return getOutput();  
    }  
  
    /** 
     * Return the output layer. 
     *  
     * @return 
     */  
    private double[] getOutput() {  
        int len = output.length;  
        double[] temp = new double[len - 1];  
        for (int i = 1; i != len; i++){
        	temp[i - 1] = output[i];
        }  
        return temp;  
    }  
  
    /** 
     * Load the target data. 
     *  
     * @param result 
     */  
    private void loadTarget(double[] result) {
        if (result.length != answer.length - 1) {  
            throw new IllegalArgumentException("Size Do Not Match.");  
        }  
        System.arraycopy(result, 0, answer, 1, result.length);  
    }  
  
    /** 
     * Load the training data. 
     *  
     * @param input_data 
     */  
    private void loadInput(double[] input_data) {
        if (input_data.length != input.length - 1) {
            throw new IllegalArgumentException("Size Do Not Match.");  
        }  
        System.arraycopy(input_data, 0, input, 1, input_data.length);  
    }  
  
    /** 
     * Forward. 
     *  
     * @param layer0 
     * @param layer1 
     * @param weight 
     */  
    private void forward(double[] layer0, double[] layer1, double[][] weight) {
        // threshold unit.  
        layer0[0] = 1.0;
        for (int j = 1, len = layer1.length; j != len; ++j) {  
            double sum = 0;  
            for (int i = 0, len2 = layer0.length; i != len2; ++i)  
                sum += weight[i][j] * layer0[i];  
            layer1[j] = sigmoid(sum);  
        }  
    }  
  
    /** 
     * Forward. 
     */  
    private void forward() {  
        forward(input, hidden_layer, input_to_hidden_weight);  
        forward(hidden_layer, output, hidden_to_output_weight);  
    }  
  
    /** 
     * Calculate output error. 
     */  
    private void outputErr() {  
        double errSum = 0;  
        for (int idx = 1, len = opt_delta.length; idx != len; ++idx) {  
            double o = output[idx];  
            opt_delta[idx] = o * (1d - o) * (answer[idx] - o);  
            errSum += Math.abs(opt_delta[idx]);  
        }  
        output_error = errSum;  
    }  
  
    /** 
     * Calculate hidden errors. 
     */  
    private void hiddenErr() {  
        double errSum = 0;  
        for (int j = 1, len = hid_delta.length; j != len; ++j) {  
            double o = hidden_layer[j];  
            double sum = 0;  
            for (int k = 1, len2 = opt_delta.length; k != len2; ++k)  
                sum += hidden_to_output_weight[j][k] * opt_delta[k];  
            hid_delta[j] = o * (1d - o) * sum;  
            errSum += Math.abs(hid_delta[j]);  
        }  
        hidden_error = errSum;  
    }  
  
    /** 
     * Calculate errors of all layers. 
     */  
    private void calculateDelta() {  
        outputErr();  
        hiddenErr();  
    }  
  
    /** 
     * Adjust the weight matrix. 
     *  
     * @param delta 
     * @param layer 
     * @param weight 
     * @param update_weight 
     */  
    private void adjustWeight(double[] delta, double[] layer, double[][] weight, double[][] update_weight) {  
  
        layer[0] = 1;  
        for (int i = 1, len = delta.length; i != len; ++i) {  
            for (int j = 0, len2 = layer.length; j != len2; ++j) {  
                double newVal = momentum * update_weight[j][i] + learning_rate * delta[i]  
                        * layer[j];  
                weight[j][i] += newVal;  
                update_weight[j][i] = newVal;  
            }  
        }  
    }  
  
    /** 
     * Adjust all weight matrices. 
     */  
    private void adjustWeight() {  
        adjustWeight(opt_delta, hidden_layer, hidden_to_output_weight, hidden_to_output_update_weight);  
        adjustWeight(hid_delta, input, input_to_hidden_weight, input_to_hidden_update_weight);  
    }  
  
    /** 
     * Sigmoid. 
     *  
     * @param val 
     * @return 
     */  
    private double sigmoid(double val) {  
        return 1d / (1d + Math.exp(-val));  
    }  
    
    
    /** 
     * Load weight data from harddisk.. 
     */
    public void loadWeight(){
    	try {
    		File file = new File(weight_file);
			FileInputStream fis = new FileInputStream(file);
			DataInputStream dis = new DataInputStream(fis);
			
			int hidden_length = hidden_layer.length;
			for(int i=0;i<hidden_length;i++){
				hidden_layer[i] = dis.readDouble();
			}
			
			int input_to_hidden_weight_length_x = input_to_hidden_weight.length;
			int input_to_hidden_weight_length_y = input_to_hidden_weight[0].length;
			for(int i=0;i<input_to_hidden_weight_length_x;i++){
				for(int j=0;j<input_to_hidden_weight_length_y;j++){
					input_to_hidden_weight[i][j] = dis.readDouble();
				}
			}
			
			int hidden_to_output_weight_length_x = hidden_to_output_weight.length;
			int hidden_to_output_weight_length_y = hidden_to_output_weight[0].length;
			for(int i=0;i<hidden_to_output_weight_length_x;i++){
				for(int j=0;j<hidden_to_output_weight_length_y;j++){
					hidden_to_output_weight[i][j] = dis.readDouble();
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    
    /** 
     * Store weight data in harddisk. 
     */
    public void storeWeight(){
    	try {
    		File file = new File(weight_file);
			FileOutputStream fos = new FileOutputStream(file);
			DataOutputStream dos = new DataOutputStream(fos);
			
			int hidden_length = hidden_layer.length;
			for(int i=0;i<hidden_length;i++){
				dos.writeDouble(hidden_layer[i]);
			}
			
			int input_to_hidden_weight_length_x = input_to_hidden_weight.length;
			int input_to_hidden_weight_length_y = input_to_hidden_weight[0].length;
			for(int i=0;i<input_to_hidden_weight_length_x;i++){
				for(int j=0;j<input_to_hidden_weight_length_y;j++){
					dos.writeDouble(input_to_hidden_weight[i][j]);
				}
			}
			
			int hidden_to_output_weight_length_x = hidden_to_output_weight.length;
			int hidden_to_output_weight_length_y = hidden_to_output_weight[0].length;
			for(int i=0;i<hidden_to_output_weight_length_x;i++){
				for(int j=0;j<hidden_to_output_weight_length_y;j++){
					dos.writeDouble(hidden_to_output_weight[i][j]);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
} 