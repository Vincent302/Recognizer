package Interface;

import java.awt.image.BufferedImage;

public interface IPicReader {
	BufferedImage getExpendedImage(BufferedImage bi);
	BufferedImage getImage();
	int [][] getImagePix(BufferedImage bi);
	double [] getBPImageInput(int [][] imagePix);
	double [] doRun();
}
